@extends('layouts.admin')

@section('title')
    List Nodes
@endsection

@section('scripts')
    @parent
    {!! Theme::css('vendor/fontawesome/animation.min.css') !!}
@endsection

@section('content-header')
    <h1>Nodes<small>All nodes available on the system.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li class="active">Nodes</li>
    </ol>
@endsection

@section('content')
<style>
    .node-grid {
        display: flex;
        flex-wrap: wrap;
        gap: 15px;
    }

    .node-card {
        flex: 1 1 calc(33.333% - 15px);
        min-width: 250px;
        border: 1px solid rgba(255,255,255,0.05);
        border-radius: 8px;
        background: linear-gradient(145deg, #3b4956, #33404d); /* slight depth */
        padding: 15px;
        position: relative;
        color: #dfe4ea;
        box-shadow:
            0 2px 6px rgba(0,0,0,0.35),
            inset 0 1px 0 rgba(255,255,255,0.05); /* subtle inset light */
        transition: all 0.25s ease-in-out;
        cursor: pointer;
    }

    .node-card a {
        color: #5dade2;
        text-decoration: none;
    }

    .node-card:hover a {
        text-decoration: underline;
    }

    .node-card:hover {
        background: linear-gradient(145deg, #445462, #3f4d5a);
        border-color: rgba(255,255,255,0.08);
        transform: translateY(-3px);
        box-shadow:
            0 6px 12px rgba(0,0,0,0.4),
            inset 0 1px 0 rgba(255,255,255,0.05);
    }

    .node-card .top-icons {
        position: absolute;
        top: 10px;
        right: 10px;
        display: flex;
        gap: 8px;
        align-items: center;
    }

    .node-card .top-icons i {
        color: #b0bec5;
        transition: color 0.2s;
    }

    .node-card:hover .top-icons i {
        color: #ffffff;
    }

    .node-card .node-name {
        margin-bottom: 10px;
        padding-right: 60px;
    }

    .node-card .node-name a {
        font-weight: 600;
        font-size: 15px;
        color: #6cb8ff; /* lighter modern blue */
        text-decoration: none;
        transition: color 0.2s;
    }

    .node-card .info-row {
        display: flex;
        flex-direction: column;
        gap: 6px;
        font-size: 13px;
        color: #cfd8dc;
    }

    .node-card .info-row div {
        display: flex;
        align-items: center;
    }

    .node-card .info-row i {
        width: 16px;
        text-align: center;
        margin-right: 6px;
        color: #6cb8ff;
    }

    /* Info Grid Styling */
    .info-grid {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
    }

    .info-box {
        flex: 1 1 120px;
        border: 1px solid rgba(255,255,255,0.08);
        border-radius: 6px;
        padding: 8px;
        background: rgba(255,255,255,0.03);
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        min-height: 65px;
        text-align: center;
    }

    .info-box i {
        color: #6cb8ff;
        font-size: 16px;
        margin-bottom: 5px;
    }

    .info-box span {
        font-size: 12px;
        color: #aab4be;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .info-box strong {
        font-size: 13px;
        color: #ffffff;
        font-weight: 600;
        margin-top: 2px;
    }

    .node-card:hover .info-box {
        border-color: rgba(255, 255, 255, 0.15);
        background: rgba(255, 255, 255, 0.06);
    }

    .maintenance-label {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: #f5b041 !important; /* softer yellow, not too bright */
        color: #2b3843 !important; /* matches your theme text tone */
        font-weight: 600;
        font-family: inherit;
        border-radius: 6px;
        padding: 5px 10px;
        font-size: 14px;
        text-shadow: none;
        border: 1px solid rgba(0,0,0,0.15);
        box-shadow: 0 1px 2px rgba(0,0,0,0.2), inset 0 1px 0 rgba(255,255,255,0.1);
        letter-spacing: 0.3px;
        transition: all 0.2s ease-in-out;
    }

    .maintenance-label:hover {
        background: #f8c471 !important;
    }

    .maintenance-label i {
        color: #2b3843 !important;
        font-size: 14px;
    }

    .box-primary {
        border-top-color: #1f2933;
        background: #2e3a46;
        color: #dfe4ea;
        box-shadow: inset 0 1px 0 rgba(255,255,255,0.03);
    }

    .box-primary > .box-header {
        background-color: #1f2933;
        color: #fff;
        border-bottom: 1px solid rgba(255,255,255,0.05);
    }

    body {
        background-color: #2b3843 !important;
        color: #dfe4ea !important;
    }
</style>


<div class="box box-primary">
    <div class="box-header with-border">
        <h3 class="box-title">Node List</h3>
        <div class="box-tools search01">
            <form action="{{ route('admin.nodes') }}" method="GET">
                <div class="input-group input-group-sm">
                    <input type="text" name="filter[name]" class="form-control pull-right" value="{{ request()->input('filter.name') }}" placeholder="Search Nodes">
                    <div class="input-group-btn">
                        <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                        <a href="{{ route('admin.nodes.new') }}">
                            <button type="button" class="btn btn-sm btn-primary" style="border-radius: 0 3px 3px 0;margin-left:-1px;">Create New</button>
                        </a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

@php
    $grouped = $nodes->groupBy('location.short');
@endphp

@foreach ($grouped as $location => $group)
<div class="box box-primary">
    <div class="box-header with-border" style="position: relative;">
        <h4 style="margin:0;">{{ $location }}</h4>
        @php
            $locationId = optional($group->first()->location)->id ?? null;
        @endphp
        @if($locationId)
            <div style="
                position: absolute;
                right: 15px;
                top: 50%;
                transform: translateY(-50%);
                display: flex;
                align-items: center;
                gap: 6px;
                color: #aab4be;
                font-size: 13px;
                background: rgba(255, 255, 255, 0.08);
                padding: 4px 8px;
                border-radius: 6px;
            ">
                <i class="fa fa-map-marker-alt" style="color:#6cb8ff;"></i>
                <span>#{{ $locationId }}</span>
            </div>
        @endif
    </div>
    <div class="box-body">
        <div class="node-grid">
            @foreach ($group as $node)
                <div class="node-card" data-link="{{ route('admin.nodes.view', $node->id) }}">
                    <div class="top-icons">
                        @if($node->behind_proxy)
                            <i class="fa-brands fa-cloudflare" style="color:#f38020;"></i>
                        @endif
                        <div data-action="ping"
                            data-secret="{{ $node->getDecryptedKey() }}"
                            data-location="{{ $node->scheme }}://{{ $node->fqdn }}:{{ $node->daemonListen }}/api/system">
                            <i class="fa fa-fw fa-refresh fa-spin text-muted"></i>
                        </div>
                        <i class="fa fa-{{ $node->scheme === 'https' ? 'lock' : 'unlock' }}"
                        style="color:{{ $node->scheme === 'https' ? '#50af51' : '#d9534f' }}"></i>
                        <i class="fa fa-{{ $node->public ? 'eye' : 'eye-slash' }}"></i>
                    </div>

                    <div class="node-name">
                        @if($node->maintenance_mode)
                            <span class="label label-warning maintenance-label">
                                <i class="fa fa-wrench"></i> {{ $node->name }}
                            </span>
                        @else
                            <a>{{ $node->name }}</a>
                        @endif
                    </div>

                    <div class="info-grid">
                        <div class="info-box">
                            <i class="fa fa-network-wired"></i>
                            <strong>#{{ $node->id }}</strong>
                        </div>
                        <div class="info-box">
                            <i class="fa fa-users"></i>
                            <strong>{{ $node->servers_count }}</strong>
                        </div>
                        <div class="info-box">
                            <i class="fa fa-memory"></i>
                            <strong>{{ $node->memory }} MiB</strong>
                        </div>
                        <div class="info-box">
                            <i class="fa fa-hdd"></i>
                            <strong>{{ $node->disk }} MiB</strong>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</div>
@endforeach

@if($nodes->hasPages())
    <div class="text-center">
        {!! $nodes->appends(['query' => Request::input('query')])->render() !!}
    </div>
@endif
@endsection

@section('footer-scripts')
@parent
<script>
(function pingNodes() {
    $('div[data-action="ping"]').each(function(i, element) {
        $.ajax({
            type: 'GET',
            url: $(element).data('location'),
            headers: {
                'Authorization': 'Bearer ' + $(element).data('secret'),
            },
            timeout: 5000
        }).done(function (data) {
            $(element).find('i').tooltip({ title: 'v' + data.version });
            $(element).find('i').removeClass().addClass('fa fa-fw fa-heartbeat faa-pulse animated').css('color', '#50af51');
        }).fail(function (error) {
            var errorText = 'Error connecting to node!';
            try { errorText = error.responseJSON.errors[0].detail || errorText; } catch (ex) {}
            $(element).find('i').removeClass().addClass('fa fa-fw fa-heartbeat').css('color', '#d9534f').tooltip({ title: errorText });
        });
    }).promise().done(function () {
        setTimeout(pingNodes, 10000);
    });
})();

$(document).ready(function() {
    $('.node-card').on('click', function(e) {
        if ($(e.target).is('a, button, i')) return;
        window.location = $(this).data('link');
    });
});
</script>
@endsection
