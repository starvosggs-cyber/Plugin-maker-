@extends('layouts.admin')

@section('title')
    {{ $node->name }}: Servers
@endsection

@section('content-header')
    <h1>{{ $node->name }}<small>All servers currently assigned to this node.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li><a href="{{ route('admin.nodes') }}">Nodes</a></li>
        <li><a href="{{ route('admin.nodes.view', $node->id) }}">{{ $node->name }}</a></li>
        <li class="active">Servers</li>
    </ol>
@endsection

@section('content')
<style>
    .server-grid {
        display: flex;
        flex-wrap: wrap;
        gap: 15px;
    }

    .server-card {
        flex: 1 1 calc(33.333% - 15px);
        min-width: 260px;
        border: 1px solid rgba(255,255,255,0.05);
        border-radius: 8px;
        background: linear-gradient(145deg, #3b4956, #33404d);
        padding: 15px;
        position: relative;
        color: #dfe4ea;
        box-shadow: 0 2px 6px rgba(0,0,0,0.35), inset 0 1px 0 rgba(255,255,255,0.05);
        transition: all 0.25s ease-in-out;
        cursor: pointer;
    }

    .server-card:hover {
        background: linear-gradient(145deg, #445462, #3f4d5a);
        border-color: rgba(255,255,255,0.08);
        transform: translateY(-3px);
        box-shadow: 0 6px 12px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.05);
    }

    .server-card .top-icons {
        position: absolute;
        top: 10px;
        right: 10px;
        display: flex;
        gap: 8px;
        align-items: center;
    }

    .server-card .top-icons i {
        font-size: 16px;
        transition: color 0.2s;
    }

    .server-card .server-name {
        margin-bottom: 8px;
        padding-right: 60px;
    }

    .server-card .server-name a {
        font-weight: 600;
        font-size: 15px;
        color: #6cb8ff;
        text-decoration: none;
        transition: color 0.2s;
    }

    .info-grid {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
    }

    .info-box {
        flex: 1 1 120px;
        border: 1px solid rgba(255,255,255,0.08);
        border-radius: 6px;
        padding: 8px;
        background: rgba(255,255,255,0.03);
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        min-height: 65px;
        text-align: center;
    }

    .info-box i {
        color: #6cb8ff;
        font-size: 16px;
        margin-bottom: 4px;
    }

    .info-box strong {
        font-size: 13px;
        color: #ffffff;
        font-weight: 600;
    }

    .box-primary {
        border-top-color: #1f2933;
        background: #2e3a46;
        color: #dfe4ea;
    }

    .box-primary > .box-header {
        background-color: #1f2933;
        color: #fff;
        border-bottom: 1px solid rgba(255,255,255,0.05);
    }

    body {
        background-color: #2b3843 !important;
        color: #dfe4ea !important;
    }
</style>

@php
    $grouped = $servers->groupBy(fn($server) => $server->user->username ?? 'Unknown Owner');
@endphp

<div class="row">
    <div class="col-xs-12">
        <div class="nav-tabs-custom nav-tabs-floating">
            <ul class="nav nav-tabs">
                <li><a href="{{ route('admin.nodes.view', $node->id) }}">About</a></li>
                <li><a href="{{ route('admin.nodes.view.settings', $node->id) }}">Settings</a></li>
                <li><a href="{{ route('admin.nodes.view.configuration', $node->id) }}">Configuration</a></li>
                <li><a href="{{ route('admin.nodes.view.allocation', $node->id) }}">Allocation</a></li>
                <li class="active"><a href="{{ route('admin.nodes.view.servers', $node->id) }}">Servers</a></li>
            </ul>
        </div>
    </div>
</div>
@foreach ($grouped as $owner => $group)
<div class="box box-primary">
    <div class="box-header with-border" style="position: relative;">
        <h4 style="margin:0;">
            <a href="{{ route('admin.users.view', $group->first()->owner_id) }}" style="color:#6cb8ff;text-decoration:none;">
                <i class="fa fa-user"></i> {{ $owner }}
            </a>
        </h4>
        <div style="
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #aab4be;
            font-size: 13px;
            background: rgba(255, 255, 255, 0.08);
            padding: 4px 8px;
            border-radius: 6px;
        ">
            {{ $group->count() }} Server{{ $group->count() > 1 ? 's' : '' }}
        </div>
    </div>
    <div class="box-body">
        <div class="server-grid">
            @foreach ($group as $server)
                <div class="server-card" data-link="{{ route('admin.servers.view', $server->id) }}">
                    <div class="top-icons">
                        @if($server->isSuspended())
                            <i class="fa fa-power-off" style="color: #f5b041;" title="Suspended"></i>
                        @elif($server->isInstalling())
                            <i class="fa fa-power-off" style="color: #6cb8ff;" title="Installing"></i>
                        @else
                            <i class="fa fa-power-off" style="color: #50af51;" title="Active"></i>
                        @endif
                    </div>

                    <div class="server-name">
                        <a href="{{ route('admin.servers.view', $server->id) }}">{{ $server->name }}</a>
                    </div>

                    <div class="info-grid">
                        <div class="info-box">
                            <i class="fa fa-server"></i>
                            <strong>{{ $server->uuidShort }}</strong>
                        </div>
                        <div class="info-box">
                            <i class="fa fa-egg"></i>
                            <strong>{{ $server->egg->name }}</strong>
                        </div>
                        <div class="info-box">
                            <i class="fa fa-memory"></i>
                            <strong>{{ $server->memory }} MiB</strong>
                        </div>
                        <div class="info-box">
                            <i class="fa fa-hdd"></i>
                            <strong>{{ $server->disk }} MiB</strong>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</div>
@endforeach

@if($servers->hasPages())
    <div class="text-center">
        {!! $servers->render() !!}
    </div>
@endif

@endsection

@section('footer-scripts')
@parent
<script>
$(document).ready(function() {
    $('.server-card').on('click', function(e) {
        if ($(e.target).is('a, button, i')) return;
        window.location = $(this).data('link');
    });
});
</script>
@endsection
