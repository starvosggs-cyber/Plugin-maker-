@extends('layouts.admin')

@section('title')
    Locations
@endsection

@section('content-header')
    <h1>Locations<small>All locations that nodes can be assigned to for easier categorization.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li class="active">Locations</li>
    </ol>
@endsection

@section('content')
<style>
    .location-grid {
        display: flex;
        flex-wrap: wrap;
        gap: 15px;
    }

    .location-card {
        flex: 1 1 calc(33.333% - 15px);
        min-width: 260px;
        border: 1px solid rgba(255,255,255,0.05);
        border-radius: 8px;
        background: linear-gradient(145deg, #3b4956, #33404d);
        padding: 15px;
        position: relative;
        color: #dfe4ea;
        box-shadow: 0 2px 6px rgba(0,0,0,0.35), inset 0 1px 0 rgba(255,255,255,0.05);
        transition: all 0.25s ease-in-out;
        cursor: pointer;
    }

    .location-card:hover {
        background: linear-gradient(145deg, #445462, #3f4d5a);
        border-color: rgba(255,255,255,0.08);
        transform: translateY(-3px);
        box-shadow: 0 6px 12px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.05);
    }

    .location-card .top-icons {
        position: absolute;
        top: 10px;
        right: 10px;
        font-size: 13px;
        background: rgba(255, 255, 255, 0.08);
        padding: 4px 8px;
        border-radius: 6px;
        color: #aab4be;
    }

    .location-card .location-name {
        margin-bottom: 8px;
        padding-right: 60px;
    }

    .location-card .location-name a {
        font-weight: 600;
        font-size: 15px;
        color: #6cb8ff;
        text-decoration: none;
    }

    .info-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
        gap: 8px;
        margin-top: 10px;
    }

    .info-box {
        border: 1px solid rgba(255,255,255,0.08);
        border-radius: 6px;
        padding: 8px;
        background: rgba(255,255,255,0.03);
        text-align: center;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        min-height: 65px;
    }

    .info-box i {
        color: #6cb8ff;
        font-size: 16px;
        margin-bottom: 4px;
    }

    .info-box strong {
        font-size: 13px;
        color: #ffffff;
        font-weight: 600;
    }

    .box-primary {
        border-top-color: #1f2933;
        background: #2e3a46;
        color: #dfe4ea;
    }

    .box-primary > .box-header {
        background-color: #1f2933;
        color: #fff;
        border-bottom: 1px solid rgba(255,255,255,0.05);
    }

    body {
        background-color: #2b3843 !important;
        color: #dfe4ea !important;
    }
</style>

<div class="row">
    <div class="col-xs-12">
        <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title">Location List</h3>
                <div class="box-tools">
                    <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#newLocationModal">Create New</button>
                </div>
            </div>

            <div class="box-body">
                @if($locations->isEmpty())
                    <p class="text-muted text-center">No locations have been created yet.</p>
                @else
                    <div class="location-grid">
                        @foreach ($locations as $location)
                            <div class="location-card" data-link="{{ route('admin.locations.view', $location->id) }}">
                                <div class="top-icons">
                                    <i class="fa fa-map-marker-alt" style="color:#6cb8ff;"></i>
                                    #{{ $location->id }}
                                </div>

                                <div class="location-name">
                                    <a href="{{ route('admin.locations.view', $location->id) }}">{{ $location->short }}</a>
                                </div>

                                <p style="margin: 0 0 10px;">{{ $location->long }}</p>

                                <div class="info-grid">
                                    <div class="info-box">
                                        <i class="fa fa-network-wired"></i>
                                        <strong>{{ $location->nodes_count }} Node{{ $location->nodes_count > 1 ? 's' : '' }}</strong>
                                    </div>
                                    <div class="info-box">
                                        <i class="fa fa-server"></i>
                                        <strong>{{ $location->servers_count }} Server{{ $location->servers_count > 1 ? 's' : '' }}</strong>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                @endif
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="newLocationModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form action="{{ route('admin.locations') }}" method="POST">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Create Location</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <label for="pShortModal" class="form-label">Short Code</label>
                            <input type="text" name="short" id="pShortModal" class="form-control" />
                            <p class="text-muted small">A short identifier used to distinguish this location from others. Must be between 1 and 60 characters, for example, <code>us.nyc.lvl3</code>.</p>
                        </div>
                        <div class="col-md-12">
                            <label for="pLongModal" class="form-label">Description</label>
                            <textarea name="long" id="pLongModal" class="form-control" rows="4"></textarea>
                            <p class="text-muted small">A longer description of this location. Must be less than 191 characters.</p>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    {!! csrf_field() !!}
                    <button type="button" class="btn btn-default btn-sm pull-left" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success btn-sm">Create</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@section('footer-scripts')
@parent
<script>
$(document).ready(function() {
    $('.location-card').on('click', function(e) {
        if ($(e.target).is('a, button, i, code')) return;
        window.location = $(this).data('link');
    });
});
</script>
@endsection