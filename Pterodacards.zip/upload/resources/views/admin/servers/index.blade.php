@extends('layouts.admin')

@section('title')
    Servers
@endsection

@section('content-header')
    <h1>Servers<small>All servers available on the system.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li class="active">Servers</li>
    </ol>
@endsection

@section('content')
<style>
    .server-grid {
        display: flex;
        flex-wrap: wrap;
        gap: 15px;
    }

    .server-card {
        flex: 1 1 calc(33.333% - 15px);
        min-width: 260px;
        border: 1px solid rgba(255,255,255,0.05);
        border-radius: 8px;
        background: linear-gradient(145deg, #3b4956, #33404d);
        padding: 15px;
        position: relative;
        color: #dfe4ea;
        box-shadow: 0 2px 6px rgba(0,0,0,0.35), inset 0 1px 0 rgba(255,255,255,0.05);
        transition: all 0.25s ease-in-out;
        cursor: pointer;
    }

    .server-card:hover {
        background: linear-gradient(145deg, #445462, #3f4d5a);
        border-color: rgba(255,255,255,0.08);
        transform: translateY(-3px);
        box-shadow: 0 6px 12px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.05);
    }

    .server-card .top-icons {
        position: absolute;
        top: 10px;
        right: 10px;
        display: flex;
        gap: 8px;
        align-items: center;
    }

    .server-card .top-icons i {
        font-size: 16px;
        transition: color 0.2s;
    }

    .server-card .server-name {
        margin-bottom: 8px;
        padding-right: 60px;
    }

    .server-card .server-name a {
        font-weight: 600;
        font-size: 15px;
        color: #6cb8ff;
        text-decoration: none;
        transition: color 0.2s;
    }

    .info-grid {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
    }

    .info-box {
        flex: 1 1 120px;
        border: 1px solid rgba(255,255,255,0.08);
        border-radius: 6px;
        padding: 8px;
        background: rgba(255,255,255,0.03);
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        min-height: 65px;
        text-align: center;
    }

    .info-box i {
        color: #6cb8ff;
        font-size: 16px;
        margin-bottom: 4px;
    }

    .info-box strong {
        font-size: 13px;
        color: #ffffff;
        font-weight: 600;
    }

    .box-primary {
        border-top-color: #1f2933;
        background: #2e3a46;
        color: #dfe4ea;
    }

    .box-primary > .box-header {
        background-color: #1f2933;
        color: #fff;
        border-bottom: 1px solid rgba(255,255,255,0.05);
    }

    body {
        background-color: #2b3843 !important;
        color: #dfe4ea !important;
    }

    .search-bar {
        margin-bottom: 20px;
        text-align: right;
    }
    .search-bar input {
        width: 220px;
        border-radius: 5px;
        border: 1px solid #555;
        padding: 6px 10px;
        background: #3b4956;
        color: #fff;
    }
</style>

@php
    $grouped = $servers->groupBy(fn($server) => $server->node->name ?? 'Unknown Node');
@endphp

<div class="box box-primary">
    <div class="box-header with-border">
        <h3 class="box-title">Server List</h3>
        <div class="box-tools search01">
            <form action="{{ route('admin.servers') }}" method="GET">
                <div class="input-group input-group-sm">
                    <input type="text" name="filter[*]" class="form-control pull-right" value="{{ request()->input()['filter']['*'] ?? '' }}" placeholder="Search Servers">
                    <div class="input-group-btn">
                        <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                        <a href="{{ route('admin.servers.new') }}"><button type="button" class="btn btn-sm btn-primary" style="border-radius: 0 3px 3px 0;margin-left:-1px;">Create New</button></a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

@foreach ($grouped as $nodeName => $group)
<div class="box box-primary">
    <div class="box-header with-border" style="position: relative;">
        <h4 style="margin:0;">
            <a href="{{ route('admin.nodes.view', $group->first()->node_id) }}" style="color:#6cb8ff;text-decoration:none;">
                <i class="fa fa-network-wired"></i> {{ $nodeName }}
            </a>
        </h4>
        <div style="
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #aab4be;
            font-size: 13px;
            background: rgba(255, 255, 255, 0.08);
            padding: 4px 8px;
            border-radius: 6px;
        ">
            {{ $group->count() }} Server{{ $group->count() > 1 ? 's' : '' }}
        </div>
    </div>

    <div class="box-body">
        <div class="server-grid">
            @foreach ($group as $server)
                <div class="server-card" data-link="{{ route('admin.servers.view', $server->id) }}">
                    <div class="top-icons">
                        <code>{{ $server->allocation->alias }}:{{ $server->allocation->port }}</code>
                        @if($server->isSuspended())
                            <i class="fa fa-power-off" style="color: #f5b041;" title="Suspended"></i>
                        @else
                            <i class="fa fa-power-off" style="color: #50af51;" title="Active"></i>
                        @endif
                    </div>

                    <div class="server-name">
                        <a href="{{ route('admin.users.view', $server->user->id) }}"><i class="fa fa-user"></i> {{ $server->user->username }}</a>
                        |
                        <a href="{{ route('admin.servers.view', $server->id) }}">{{ $server->name }}</a>
                    </div>

                    <div class="info-grid">
                        <div class="info-box">
                            <i class="fa fa-server"></i>
                            <strong>{{ $server->uuidShort }}</strong>
                        </div>
                        <div class="info-box">
                            <i class="fa fa-egg"></i>
                            <strong>{{ $server->egg->name }}</strong>
                        </div>
                        <div class="info-box">
                            <i class="fa fa-memory"></i>
                            <strong>{{ $server->memory }} MiB</strong>
                        </div>
                        <div class="info-box">
                            <i class="fa fa-hdd"></i>
                            <strong>{{ $server->disk }} MiB</strong>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</div>
@endforeach

@if($servers->hasPages())
    <div class="text-center">
        {!! $servers->appends(['filter' => Request::input('filter')])->render() !!}
    </div>
@endif
@endsection

@section('footer-scripts')
@parent
<script>
$(document).ready(function() {
    $('.server-card').on('click', function(e) {
        if ($(e.target).is('a, button, i')) return;
        window.location = $(this).data('link');
    });
});
</script>
@endsection
