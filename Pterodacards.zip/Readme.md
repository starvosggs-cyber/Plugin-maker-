\## Manual installation

1\. Upload all file from the `upload` folders into `/var/www/pterodactyl`

2\. Go To `resources/views/admin/locations/index.blade.php` and search

```

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

```

replace it to this snippet

```

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/brands.min.css" integrity="sha384-<appropriate-hash>" crossorigin="anonymous">

```

