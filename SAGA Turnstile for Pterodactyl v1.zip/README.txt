Thank you for purchasing SAGA's Addon!

To unlock the installation guide,
1. Please Join to our SAGA's Discord here https://discord.gg/DU8cjUJjeN
2. Link your Discord with BBB here https://builtbybit.com/account/discord/ 
3. Go to SAGA's Discord #general channel and run /sync command there
4. Wait a few minutes until you see new channel unlocked named your purchased addon